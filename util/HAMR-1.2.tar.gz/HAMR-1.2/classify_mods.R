
#!/usr/bin/Rscript env

# Copyright (c) 2013 University of Pennsylvania

# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.



library('class')

if (length(commandArgs(T)) < 2) {
  cat("USAGE: classify_mods.R table model\n")
  q()
}

infn = commandArgs(T)[1]
modelfn = commandArgs(T)[2]

load(modelfn)

nucs = c('A','C','G','T')

x = read.table(infn, as.is=T, sep="\t", header=T)

x = x[x$sig == TRUE,]

for(i in 1:nrow(x)) {
 precursor = sub('T', 'U', x[i,'refnuc']) 
  x.p = pred.mod(modmodel2, precursor,
    (data.frame(x[i,nucs[nucs != x[i,'refnuc']]])))
  x[i,'pred.mod'] = x.p
}

write.table(x, file="", row.names=F, col.names=T, quote=F,sep="\t")



